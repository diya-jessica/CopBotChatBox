
import re
import numpy as np
import pandas as pd
from io import BytesIO
from typing import Tuple, List
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores.faiss import FAISS
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings

from pypdf import PdfReader
from docx import Document as DocxDocument
import faiss

def parse_file(file: BytesIO, filename: str) -> Tuple[List[str], str]:
    """Parse different document types (PDF, DOCX, XLSX)."""
    output = []
    
    if filename.lower().endswith(".pdf"):
        pdf = PdfReader(file)
        for page in pdf.pages:
            text = page.extract_text()
            if text:  # Ensure text is not None
                text = re.sub(r"(\w+)-\n(\w+)", r"\1\2", text)  # Fix hyphenated words
                text = re.sub(r"(?<!\n\s)\n(?!\s\n)", " ", text.strip())  # Fix line breaks
                text = re.sub(r"\n\s*\n", "\n\n", text)  # Remove excessive newlines
                output.append(text)
    
    elif filename.lower().endswith(".docx"):
        doc = DocxDocument(file)
        for para in doc.paragraphs:
            output.append(para.text.strip())

    elif filename.lower().endswith(".xlsx"):
        file.seek(0)
        df = pd.read_excel(file, sheet_name=None, engine="openpyxl")  # Explicit engine
        for sheet_name, sheet in df.items():
            output.append(f"Sheet: {sheet_name}\n" + sheet.to_string(index=False))

    return output, filename

def text_to_docs(text: List[str], filename: str) -> List[Document]:
    """Convert text chunks into LangChain Document objects."""
    if isinstance(text, str):
        text = [text]
    page_docs = [Document(page_content=page, metadata={"page": i + 1}) for i, page in enumerate(text)]
    
    doc_chunks = []
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=4000, chunk_overlap=0)
    for doc in page_docs:
        chunks = text_splitter.split_text(doc.page_content)
        for i, chunk in enumerate(chunks):
            doc_chunk = Document(
                page_content=chunk,
                metadata={"page": doc.metadata["page"], "chunk": i, "filename": filename}
            )
            doc_chunk.metadata["source"] = f"{doc_chunk.metadata['page']}-{doc_chunk.metadata['chunk']}"
            doc_chunks.append(doc_chunk)
    return doc_chunks

def docs_to_index(docs: List[Document]):
    """Convert documents into a FAISS index using Hugging Face embeddings."""
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L12-v2")
    index = FAISS.from_documents(docs, embeddings)
    return index

def get_index_for_documents(files: List[BytesIO], filenames: List[str]):
    """Process uploaded files and create a FAISS index."""
    documents = []
    for file, filename in zip(files, filenames):
        if isinstance(file, tuple):
            file = file[0]  # Extract actual file object if tuple
        file = BytesIO(file)  # Ensure it's a BytesIO object
        text, filename = parse_file(file, filename)
        documents.extend(text_to_docs(text, filename))
    
    if not documents:
        raise ValueError("No valid documents found for indexing.")
    
    index = docs_to_index(documents)
    return index
