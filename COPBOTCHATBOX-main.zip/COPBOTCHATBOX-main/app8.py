
import streamlit as st
st.markdown(
    """
    <style>
    /* Set background image */
    .stApp {
        background: url('BG.png') no-repeat center center fixed;
        background-size: cover;
    }
    
    /* Dark overlay to make text readable */
    .stApp::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: -1;
    }

    /* Style for input box */
    .stTextInput, .stTextArea {
        border: 2px solid #4CAF50 !important;
        border-radius: 8px;
        padding: 10px;
        color: white;
        background-color: #222;
    }

    /* Style the title */
    h1 {
        color: white !important;
        text-align: center;
        font-weight: bold;
    }

    /* Style the chatbot response area */
    .stChatMessage {
        background-color: rgba(255, 255, 255, 0.2);
        padding: 15px;
        border-radius: 8px;
        color: white;
    }

    </style>
    """,
    unsafe_allow_html=True
)

import os
import pdfplumber
import json
import hashlib
from langchain_community.chat_models import ChatOllama
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from docx import Document
import pandas as pd
from brain2 import get_index_for_documents


# Directory for storing police documents
PDF_FOLDER = "police_documents"
os.makedirs(PDF_FOLDER, exist_ok=True)

# Authentication details
USER_CREDENTIALS = {
    "admin": "1b25a2b024bc5f30d34dbe214518b52a22c7c88e8aee1dc1e141adc1a9cdeded"  # Hash for 'Deepika@12'
}

# Function to extract text from PDFs
def extract_text_from_pdfs(directory):
    data = []
    pdf_files = [os.path.join(directory, file) for file in os.listdir(directory) if file.endswith(".pdf")]
    for pdf_path in pdf_files:
        with pdfplumber.open(pdf_path) as pdf:
            text = "\n".join([page.extract_text() for page in pdf.pages if page.extract_text()])
            data.append({"prompt": "Extracted police data", "completion": text})
    return data

# Function to extract text from DOCX files
def extract_text_from_docx(directory):
    data = []
    docx_files = [os.path.join(directory, file) for file in os.listdir(directory) if file.endswith(".docx")]
    for docx_path in docx_files:
        doc = Document(docx_path)
        text = "\n".join([para.text for para in doc.paragraphs if para.text.strip()])
        data.append({"prompt": "Extracted police data", "completion": text})
    return data

# Load and preprocess police data
def load_police_data():
    qa_data = extract_text_from_pdfs(PDF_FOLDER) + extract_text_from_docx(PDF_FOLDER)
    if qa_data:
        with open("police_finetune_data.jsonl", "w") as f:
            for entry in qa_data:
                f.write(json.dumps(entry) + "\n")
    return qa_data

# Function to create FAISS vector database
def create_faiss_index():
    with open("police_finetune_data.jsonl", "r") as f:
        documents = [json.loads(line)["completion"] for line in f]
    embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectordb = FAISS.from_texts(documents, embedding_model)
    vectordb.save_local("faiss_index")
    return vectordb

# Load pre-existing data or create a new vector database
if os.path.exists("police_finetune_data.jsonl"):
    vectordb = create_faiss_index()
else:
    vectordb = None

# Function to check authentication
def authenticate_user(username, password):
    if username in USER_CREDENTIALS:
        input_hash = hashlib.sha256(password.encode()).hexdigest()
        return input_hash == USER_CREDENTIALS[username]
    return False

# Streamlit UI
st.title("🚔 Police Assistance Chatbot (RAG-powered)")

# 📌 Chatbot for Normal Users
st.header("💬 Chat with Police Assistance AI")

if "chat_history" not in st.session_state:
    st.session_state["chat_history"] = []

question = st.chat_input("Ask anything about police procedures...")

if question:
    st.session_state["chat_history"].append(("user", question))
    
    if vectordb is None:
        response = "⚠️ No police data available. Please wait for document uploads."
    else:
        search_results = vectordb.similarity_search(question, k=3)
        if not search_results or not search_results[0].page_content.strip():
            response = "⚠️ I can only answer based on the available police documents."
        else:
            doc_extract = "\n".join([result.page_content for result in search_results])
            llm = ChatOllama(model="mistral")
            response = llm.predict(f"Context:\n{doc_extract}\n\nUser Question: {question}").strip()
    
    st.session_state["chat_history"].append(("assistant", response))
    
for role, msg in st.session_state["chat_history"]:
    st.chat_message(role).write(msg)

# 📌 Police Officer Login for Document Upload
st.sidebar.header("🔒 Police Officer Login")

if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False

if not st.session_state["authenticated"]:
    username = st.sidebar.text_input("Enter Username:")
    password = st.sidebar.text_input("Enter Password:", type="password")
    if st.sidebar.button("Login"):
        if authenticate_user(username, password):
            st.session_state["authenticated"] = True
            st.sidebar.success("✅ Authentication successful!")
        else:
            st.sidebar.error("❌ Incorrect username or password!")
    st.stop()

st.sidebar.header("📂 Upload Police Documents")

uploaded_files = st.sidebar.file_uploader(
    "Upload PDF or DOCX", 
    accept_multiple_files=True, 
    type=["pdf", "docx"]
)

if uploaded_files:
    for uploaded_file in uploaded_files:
        file_path = os.path.join(PDF_FOLDER, uploaded_file.name)
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

    st.sidebar.success("✅ Documents uploaded successfully!")

    # Update fine-tuning and FAISS index
    load_police_data()
    vectordb = create_faiss_index()
    st.sidebar.success("✅ AI knowledge base updated!")
