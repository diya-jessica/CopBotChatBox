import hashlib
import json
import streamlit as st
import os
import base64
# Removed the import as it is not used in the code
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from langchain_community.chat_models import ChatOllama
from langchain.chat_models import ChatOpenAI

# from langchain.document_loaders import Document
from docx import Document
from sentence_transformers import SentenceTransformer
import pandas as pd
from brain2 import get_index_for_documents
import pdfplumber

image_path = "police.png"
with open(image_path, "rb") as img_file:
    encoded_image = base64.b64encode(img_file.read()).decode()

st.markdown(
    f"""
    <style>
    .title-container {{
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        margin-top: -90px;
        padding-left: 40px;
        padding-top: 29px;
    }}
    .title-text {{
        font-size: 2.5rem;
        font-weight: bold;
        color: white;
        text-align: center;
    }}
    .header {{
        display: flex;
        justify-content: center;  /* Align to left */
        align-items: center;
        padding-left: 100px;
    }}
        .header img {{
        width: 150px; /* Adjust size */
        height: auto;
        transform: translateX(-30px); /* Move slightly left */
        filter: blur(3px);
    }}
    </style>
    <div class="title-container">
        <h1 class="title-text">CopBot ChatBox 🕵️</h1>
    </div>
    <div class="header">
        <img src="data:image/png;base64,{encoded_image}" />
    </div>
    """,
    unsafe_allow_html=True
)
PDF_FOLDER = "police_documents"
os.makedirs(PDF_FOLDER, exist_ok=True)

USER_CREDENTIALS = {
    "admin": "1b25a2b024bc5f30d34dbe214518b52a22c7c88e8aee1dc1e141adc1a9cdeded"  # Hash for 'Deepika@12'
}

def extract_text_from_pdfs(directory):
    data = []
    pdf_files = [os.path.join(directory, file) for file in os.listdir(directory) if file.endswith(".pdf")]
    for pdf_path in pdf_files:
        with pdfplumber.open(pdf_path) as pdf:
            text = "\n".join([page.extract_text() for page in pdf.pages if page.extract_text()])
            data.append({"prompt": "Extracted police data", "completion": text})
    return data

def extract_text_from_docx(directory):
    data = []
    docx_files = [os.path.join(directory, file) for file in os.listdir(directory) if file.endswith(".docx")]
    for docx_path in docx_files:
        doc = Document(docx_path)
        text = "\n".join([para.text for para in doc.paragraphs if para.text.strip()])
        data.append({"prompt": "Extracted police data", "completion": text})
    return data

def load_police_data():
    qa_data = extract_text_from_pdfs(PDF_FOLDER) + extract_text_from_docx(PDF_FOLDER)
    if qa_data:
        with open("police_finetune_data.json", "w") as f:
            for entry in qa_data:
                f.write(json.dumps(entry) + "\n")
    return qa_data

def create_faiss_index():
    with open("police_finetune_data.json", "r") as f:
        documents = [json.loads(line)["completion"] for line in f]
    embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectordb = FAISS.from_texts(documents, embedding_model)
    vectordb.save_local("faiss_index")
    return vectordb

if os.path.exists("police_finetune_data.json"):
    vectordb = create_faiss_index()
else:
    vectordb = None

def authenticate_user(username, password):
    if username in USER_CREDENTIALS:
        input_hash = hashlib.sha256(password.encode()).hexdigest()
        return input_hash == USER_CREDENTIALS[username]
    return False

if "chat_history" not in st.session_state:
    st.session_state["chat_history"] = []

question = st.chat_input("Chat with Police Assistant AI")
if question:
    st.session_state["chat_history"].append(("user", question))
    if vectordb is None:
        st.warning("⚠️ No police data available. Please wait for document uploads.")
    else:
        search_results = vectordb.similarity_search(question, k=3)
        if not search_results or not search_results[0].page_content.strip():
            st.warning("⚠️ I can only answer based on the available police documents.")
        else:
            doc_extract = "\n".join(result.page_content for result in search_results)
            llm = ChatOpenAI(model="mistral")
            response = llm.predict(f"Context:\n{doc_extract}\n\nUser Question: {question}").strip()
            st.session_state["chat_history"].append(("assistant", response))
            for role, msg in st.session_state["chat_history"]:
                st.chat_message(role).write(msg)

st.sidebar.header("🔐 Police Officer Login")
if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False
if not st.session_state["authenticated"]:
    username = st.sidebar.text_input("Enter Username:")
    password = st.sidebar.text_input("Enter Password:", type="password")
    if st.sidebar.button("Login"):
        if authenticate_user(username, password):
            st.session_state["authenticated"] = True
            st.sidebar.success("✅ Authentication successful!")
        else:
            st.sidebar.error("❌ Incorrect username or password!")
            st.stop()
st.sidebar.header("📤 Upload Police Documents")
uploaded_files = st.sidebar.file_uploader(
    "Upload PDF or DOCX",
    accept_multiple_files=True,
    type=["pdf", "docx"]
)

if uploaded_files:
    for uploaded_file in uploaded_files:
        file_path = os.path.join(PDF_FOLDER, uploaded_file.name)
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
    st.sidebar.success("✅ Documents uploaded successfully!")
    load_police_data()
    vectordb = create_faiss_index()
    st.sidebar.success("✅ AI knowledge base updated!")



