
import hashlib
print(hashlib.sha256("Deepika@12".encode()).hexdigest())
